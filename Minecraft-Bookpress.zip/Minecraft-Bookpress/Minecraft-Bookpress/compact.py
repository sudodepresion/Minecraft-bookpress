import pynput
import time
from pynput.mouse import Button, Controller as MouseController
from pynput.keyboard import Key, Controller as KeyboardController
import sys
import ctypes


cordsX = sys.argv[2]
cordsY = sys.argv[3]

def click_next_page():
    mouse = MouseController()
    mouse.position = (cordsX, cordsY) #may change depending on your resolution
    time.sleep(0.1) #increase this if your game lags
    mouse.press(Button.left)
    mouse.release(Button.left)
    time.sleep(0.1) #increase this if your game lags 

def makro(message):
    charLim = 266
    char_list = list(message)
    for i in range(len(char_list)):
        if (i+1) > 0 and (i+1) % charLim == 0: #old charLim = 266
            click_next_page()
            KeyboardController().type(char_list[i])
        else:
            KeyboardController().type(char_list[i])

def copy_to_clipboard(text):
    # Open the clipboard
    ctypes.windll.user32.OpenClipboard(None)
    # Clear the clipboard
    ctypes.windll.user32.EmptyClipboard()
    # Allocate memory for the text
    hGlobal = ctypes.windll.kernel32.GlobalAlloc(0x0002, len(text) + 1)
    # Lock the memory
    lpText = ctypes.windll.kernel32.GlobalLock(hGlobal)
    # Copy the text to the memory
    ctypes.cdll.msvcrt.strcpy(ctypes.c_char_p(lpText), str(text))
    # Unlock the memory
    ctypes.windll.kernel32.GlobalUnlock(hGlobal)
    # Set the clipboard data
    ctypes.windll.user32.SetClipboardData(13, hGlobal)
    # Close the clipboard
    ctypes.windll.user32.CloseClipboard()


time.sleep(2)



try:
    input_str = sys.argv[1]
    makro(input_str)
except Exception as error:
    copy_to_clipboard(error)
