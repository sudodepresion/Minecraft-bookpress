import pynput
import time
from pynput.mouse import Button, Controller as MouseController
from pynput.keyboard import Key, Controller as KeyboardController
import pyautogui
import sys

cordsX = sys.argv[2]
cordsY = sys.argv[3]

def click_next_page():
    mouse = MouseController()
    mouse.position = (cordsX, cordsY) #may change depending on your resolution
    time.sleep(0.1) #increase this if your game lags
    mouse.press(Button.left)
    mouse.release(Button.left)
    time.sleep(0.1) #increase this if your game lags 

def makro(message):
    charLim = 266
    char_list = list(message)
    for i in range(len(char_list)):
        if (i+1) > 0 and (i+1) % charLim == 0: #old charLim = 266
            click_next_page()
            KeyboardController().type(char_list[i])
        else:
            KeyboardController().type(char_list[i])

time.sleep(2)

input_str = sys.argv[1]
makro(input_str)
