﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
namespace Minecraft_Bookpress

//TODO: Check for max chars per page

{
    public partial class Form1 : Form
    { 
        public Form1()
        {
            this.TopMost = true;
            InitializeComponent();

            richTextBoxPopUp.Hide();
            this.Resize += Form1_Resize;
            downloadDepend();
        }
        public void downloadDepend()
        {
            System.Diagnostics.Process process = new System.Diagnostics.Process();
            System.Diagnostics.ProcessStartInfo startInfo = new System.Diagnostics.ProcessStartInfo();
            startInfo.WindowStyle = System.Diagnostics.ProcessWindowStyle.Hidden;
            startInfo.FileName = "cmd.exe";
            startInfo.Arguments = "/C pip install pynput";
            process.StartInfo = startInfo;
            process.Start();
        }
        void Form1_Resize(object sender, EventArgs e)
        {
            richTextBoxPopUp.Font = new Font("SimSun", (int) Math.Round(Math.Sqrt(this.Width) /1.75), FontStyle.Bold);
            richTextBoxPopUp.Width = this.Width-40;
            buttonCalibrate.Width = this.Width/2 -6;
            buttonRun.Width = this.Width / 2 - 20;
            richTextBoxInput.Height = this.Height - 90;
            richTextBoxInput.Width = this.Width - 40;
            buttonRun.Location = new Point(12, richTextBoxInput.Height + 18);
            buttonCalibrate.Location = new Point((this.Width-buttonRun.Right-30), richTextBoxInput.Height +18);
            richTextBoxPopUp.Location = new Point(12,richTextBoxInput.Height/2);
        }

        private void Form1_Load(object sender, EventArgs e)
        {
        }

        private void buttonRun_Click(object sender, EventArgs e)
        {
            var assembly = Assembly.GetExecutingAssembly();
            var resourceName = "Minecraft_Bookpress.compact.py";
            string script = "";
            
            using (Stream stream = assembly.GetManifestResourceStream(resourceName))
            using (StreamReader reader = new StreamReader(stream))
            {
                script = reader.ReadToEnd();
            }
            
            runPy(richTextBoxInput.Text, script, globals.mouseX, globals.mouseY);
        }
        private void runPy(string input, string scriptContents, int inputX, int inputY)
        {
            ProcessStartInfo start = new ProcessStartInfo();
            start.FileName = "python";
            start.Arguments = $"-c \"{scriptContents}\" \"{input}\" {inputX} {inputY}";
            start.UseShellExecute = false;
            start.RedirectStandardOutput = true;
            start.CreateNoWindow = true;

            using (Process process = Process.Start(start))
            {
                using (StreamReader reader = process.StandardOutput)
                {
                    string result = reader.ReadToEnd();
                    Console.Write(result);
                }
            }
        }

        private async void buttonCalibrate_Click(object sender, EventArgs e)
        {
            richTextBoxPopUp.Text = "Hover mouse on the \"next Page\" button";
            richTextBoxPopUp.Show();
            await Task.Delay(3000);
            globals.mouseX = MousePosition.X;
            globals.mouseY = MousePosition.Y;
            richTextBoxPopUp.Text = "DONE";
            await Task.Delay(1000);
            richTextBoxPopUp.Hide();

        }
    }
    public static class globals
    {
        public static int mouseX;
        public static int mouseY;
    }
}
